// Represents a single node in the AVL tree
class AVLNode {
    Course data;           // Stores the course object
    AVLNode left;          // Left child in the tree
    AVLNode right;         // Right child in the tree
    int height;            // Height of the node

    AVLNode(Course data) {
        this.data = data;
        this.height = 1;  // New node is initially added at leaf
    }
}
