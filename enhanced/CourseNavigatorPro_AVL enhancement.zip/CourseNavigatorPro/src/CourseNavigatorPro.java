import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// This is the main class that runs the program
public class CourseNavigatorPro {

    public static void main(String[] args) {
        // Create a new AVL Tree to store and manage courses
        AVLTree courseTree = new AVLTree();

        // Scanner is used to read input from the user
        Scanner scanner = new Scanner(System.in);
        int choice; // Variable to store the user's menu choice

        // Show welcome message when the program starts
        welcomeMessage();

        // This is the main loop that keeps showing the menu until the user exits
        while (true) {
            displayMenu(); // Show the menu options
            System.out.print("\nChoice: ");

            // Read user input and convert it to an integer
            try {
                choice = Integer.parseInt(scanner.nextLine().trim());
            } catch (Exception e) {
                // If the user enters something that's not a number, show an error
                System.out.println("⚠️ Please enter a valid number.");
                continue; // Go back to the top of the loop
            }

            // This switch statement runs different code based on the user's choice
            switch (choice) {
                case 1:
                    System.out.println("\n📘 Add New Course");
                    Course newCourse = getCourseInput(scanner); // Ask user for course details
                    courseTree.insertCourse(newCourse); // Add the course to the AVL tree
                    break;
                case 2:
                    System.out.println("\n✏️ Update an Existing Course");
                    Course updatedCourse = getCourseInput(scanner); // Ask user for updated course details
                    courseTree.updateCourse(updatedCourse); // Update the course in the AVL tree
                    break;
                case 3:
                    System.out.println("\n🗑️ Delete an Existing Course");
                    System.out.print("Enter course number to delete: ");
                    String courseToDelete = scanner.nextLine().trim(); // Get the course number to delete
                    courseTree.deleteCourse(courseToDelete); // Delete the course from the AVL tree
                    break;
                case 4:
                    System.out.println("\n📚 View All Courses");
                    courseTree.printInOrder(); // Print all courses in sorted order
                    break;
                case 9:
                    // Exit the program
                    System.out.println("\n👋 You've exited the program.");
                    scanner.close(); // Close the scanner
                    return; // End the program
                default:
                    // If the user enters an invalid option
                    System.out.println("❌ Invalid entry. Please select a valid menu option.");
            }
        }
    }

    // This method displays a CNPro welcome message
    public static void welcomeMessage() {
        System.out.println("\n📚Course Navigator Pro 📚");
    }

    // This method shows the main menu options to the user
    public static void displayMenu() {
        System.out.println("\nPlease select an option:");
        System.out.println("------------------------");
        System.out.println("1 | Add Course");
        System.out.println("2 | Update Course");
        System.out.println("3 | Delete Course");
        System.out.println("4 | View All Courses");
        System.out.println("9 | Exit Program");
    }

    // This method gets course input from the user and creates a Course object
    public static Course getCourseInput(Scanner scanner) {
        System.out.print("Enter course number (ex: CS499): ");
        String number = scanner.nextLine().trim(); // Get course number

        System.out.print("Enter course title: ");
        String title = scanner.nextLine().trim(); // Get course title

        System.out.print("Enter prerequisites (comma separated), or press Enter for none: ");
        String prereqInput = scanner.nextLine().trim(); // Get prerequisites as a single line
        List<String> prerequisites = new ArrayList<>();

        // If prerequisites were entered, split them into a list
        if (!prereqInput.isEmpty()) {
            for (String pre : prereqInput.split(",")) {
                prerequisites.add(pre.trim());
            }
        }

        // Return a new Course object with the entered details
        return new Course(number, title, prerequisites);
    }
}