import java.util.List;

// This class represents a Course with a number, title, and a list of prerequisites
public class Course {
    // Private variables that store the course's information
    private String courseNumber;              // Example: "CSCI200"
    private String courseTitle;               // Example: "Data Structures"
    private List<String> prerequisites;       // Example: ["CSCI100", "CSCI101"]

    // This is the constructor method. It runs when you create a new Course object.
    // It takes in the course number, title, and a list of prerequisites.
    public Course(String courseNumber, String courseTitle, List<String> prerequisites) {
        this.courseNumber = courseNumber;
        this.courseTitle = courseTitle;
        this.prerequisites = prerequisites;
    }

    // Getter method to get the course number
    public String getCourseNumber() {
        return courseNumber;
    }

    // Getter method to get the course title
    public String getCourseTitle() {
        return courseTitle;
    }

    // Getter method to get the list of prerequisites
    public List<String> getPrerequisites() {
        return prerequisites;
    }

    // Setter method to update the course number
    public void setCourseNumber(String courseNumber) {
        this.courseNumber = courseNumber;
    }

    // Setter method to update the course title
    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }

    // Setter method to update the list of prerequisites
    public void setPrerequisites(List<String> prerequisites) {
        this.prerequisites = prerequisites;
    }
}