public class AVLTree {

    // Inner class representing each node in the AVL tree
    private class Node {
        Course course;
        Node left, right;
        int height;

        Node(Course course) {
            this.course = course;
            height = 1; // New nodes are initially added at height 1
        }
    }

    private Node root; // Root of the AVL tree

    // Public method to insert a course into the AVL tree
    public void insertCourse(Course course) {
        root = insert(root, course);
    }

    // Recursive method to insert a course and balance the tree
    private Node insert(Node node, Course course) {
        if (node == null) return new Node(course); // Base case: insert new node

        int cmp = course.getCourseNumber().compareTo(node.course.getCourseNumber());
        if (cmp < 0)
            node.left = insert(node.left, course);  // Go left if course number is smaller
        else if (cmp > 0)
            node.right = insert(node.right, course); // Go right if course number is greater
        else
            return node; // Duplicate course; do not insert

        // Update height of this ancestor node
        node.height = 1 + Math.max(height(node.left), height(node.right));

        // Rebalance the tree if needed
        return balance(node);
    }

    // Public method to update a course by deleting and reinserting it
    public void updateCourse(Course course) {
        deleteCourse(course.getCourseNumber()); // Delete the old version
        insertCourse(course); // Insert the updated version
    }

    // Public method to delete a course from the AVL tree
    public void deleteCourse(String courseNumber) {
        root = delete(root, courseNumber);
    }

    // Recursive method to delete a course and maintain AVL balance
    private Node delete(Node node, String courseNumber) {
        if (node == null) return null; // Base case: not found

        int cmp = courseNumber.compareTo(node.course.getCourseNumber());
        if (cmp < 0)
            node.left = delete(node.left, courseNumber); // Search left
        else if (cmp > 0)
            node.right = delete(node.right, courseNumber); // Search right
        else {
            // Node with one or no children
            if (node.left == null || node.right == null)
                node = (node.left != null) ? node.left : node.right;
            else {
                // Node with two children: get the inorder successor
                Node minNode = getMinValueNode(node.right);
                node.course = minNode.course; // Replace value
                node.right = delete(node.right, minNode.course.getCourseNumber()); // Delete successor
            }
        }

        if (node == null) return null;

        // Update height and balance the node
        node.height = 1 + Math.max(height(node.left), height(node.right));
        return balance(node);
    }

    // Helper method to find the node with the smallest value (inorder successor)
    private Node getMinValueNode(Node node) {
        while (node.left != null)
            node = node.left;
        return node;
    }

    // Public method to print the AVL tree in-order
    public void printInOrder() {
        inOrderTraversal(root);
    }

    // Recursive in-order traversal (sorted order)
    private void inOrderTraversal(Node node) {
        if (node != null) {
            inOrderTraversal(node.left); // Visit left subtree
            System.out.println("------------------------");
            System.out.println("Course Number: " + node.course.getCourseNumber());
            System.out.println("Course Title: " + node.course.getCourseTitle());
            System.out.println("Prerequisites: " + String.join(", ", node.course.getPrerequisites()));
            System.out.println("------------------------");
            inOrderTraversal(node.right); // Visit right subtree
        }
    }

    // Utility method to get the height of a node
    private int height(Node node) {
        return node == null ? 0 : node.height;
    }

    // Utility method to calculate balance factor of a node
    private int getBalance(Node node) {
        return node == null ? 0 : height(node.left) - height(node.right);
    }

    // Balances a node based on AVL rules (rotations)
    private Node balance(Node node) {
        int balance = getBalance(node);

        // Left heavy
        if (balance > 1) {
            // Left-Right case
            if (getBalance(node.left) < 0)
                node.left = rotateLeft(node.left);
            return rotateRight(node); // Left-Left case
        }

        // Right heavy
        if (balance < -1) {
            // Right-Left case
            if (getBalance(node.right) > 0)
                node.right = rotateRight(node.right);
            return rotateLeft(node); // Right-Right case
        }

        return node; // Node is already balanced
    }

    // Right rotation (used for balancing)
    private Node rotateRight(Node y) {
        Node x = y.left;
        Node T2 = x.right;

        // Perform rotation
        x.right = y;
        y.left = T2;

        // Update heights
        y.height = 1 + Math.max(height(y.left), height(y.right));
        x.height = 1 + Math.max(height(x.left), height(x.right));

        return x; // New root
    }

    // Left rotation (used for balancing)
    private Node rotateLeft(Node x) {
        Node y = x.right;
        Node T2 = y.left;

        // Perform rotation
        y.left = x;
        x.right = T2;

        // Update heights
        x.height = 1 + Math.max(height(x.left), height(x.right));
        y.height = 1 + Math.max(height(y.left), height(y.right));

        return y; // New root
    }

    public Course searchCourse(String courseNumber) {
        return searchRecursive(root, courseNumber);
    }

    private Course searchRecursive(Node node, String courseNumber) {
        if (node == null) return null;

        int cmp = courseNumber.compareToIgnoreCase(node.course.getCourseNumber());
        if (cmp == 0) return node.course;
        else if (cmp < 0) return searchRecursive(node.left, courseNumber);
        else return searchRecursive(node.right, courseNumber);
    }
}
