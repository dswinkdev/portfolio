// Import necessary MongoDB classes for client connection and database operations
import com.mongodb.client.*;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.ReplaceOptions;
import org.bson.Document;

// Import Java utility classes
import java.util.ArrayList;
import java.util.List;

// Class representing the CourseDatabase that handles all MongoDB interactions
public class CourseDatabase {
    // MongoDB client used to connect to the MongoDB server
    private final MongoClient mongoClient;
    // Represents the specific database within the MongoDB server
    private final MongoDatabase database;
    // Represents the collection (table) of courses within the database
    private final MongoCollection<Document> collection;

    // Constructor: initializes the MongoDB client and connects to the database and collection
    public CourseDatabase() {
        // Connect to MongoDB server at localhost on port 27017
        mongoClient = MongoClients.create("mongodb://localhost:27017");
        // Select the "coursenavigator" database
        database = mongoClient.getDatabase("coursenavigator");
        // Select the "courses" collection within the database
        collection = database.getCollection("courses");
    }

    // Inserts a new course into the database
    public void insertCourse(Course course) {
        // Create a BSON document from the Course object
        Document doc = new Document("number", course.getCourseNumber())
                .append("title", course.getCourseTitle())
                .append("prerequisites", course.getPrerequisites());
        // Insert the document into the collection
        collection.insertOne(doc);
    }

    // Updates an existing course; if it doesn't exist, inserts it (upsert)
    public void updateCourse(Course course) {
        // Create the updated course document
        Document updatedDoc = new Document("number", course.getCourseNumber())
                .append("title", course.getCourseTitle())
                .append("prerequisites", course.getPrerequisites());

        // Replace the existing course with the same number or insert it if it doesn’t exist
        collection.replaceOne(
                Filters.eq("number", course.getCourseNumber()),  // Filter to find the course
                updatedDoc,                                      // New document to replace with
                new ReplaceOptions().upsert(true)                // Upsert = update or insert
        );
    }

    // Deletes a course from the database using the course number
    public void deleteCourse(String courseNumber) {
        // Delete the course document that matches the given course number
        collection.deleteOne(Filters.eq("number", courseNumber));
    }

    // Retrieves all courses from the database and returns them as a list
    public List<Course> getAllCourses() {
        List<Course> courses = new ArrayList<>();
        // Fetch all documents in the collection
        FindIterable<Document> docs = collection.find();

        // Convert each document into a Course object and add it to the list
        for (Document doc : docs) {
            String number = doc.getString("number");
            String title = doc.getString("title");
            List<String> prerequisites = (List<String>) doc.get("prerequisites");
            Course course = new Course(number, title, prerequisites);
            courses.add(course);
        }
        // Return the complete list of courses
        return courses;
    }

    // Closes the MongoDB client connection (important for cleanup)
    public void close() {
        mongoClient.close();
    }

    // Finds a single course in the database by course number
    public Course findCourseByNumber(String courseNumber) {
        // Look for the first document where the number matches the provided course number
        Document doc = collection.find(Filters.eq("number", courseNumber)).first();

        // If a course is found, extract its title and prerequisites, and return as a Course object
        if (doc != null) {
            String title = doc.getString("title");
            List<String> prerequisites = (List<String>) doc.get("prerequisites");
            return new Course(courseNumber, title, prerequisites);
        }
        // Return null if the course was not found
        return null;
    }
}
