// Import necessary classes for list handling and user input
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// Main class for the Course Navigator Pro application
public class CourseNavigatorPro {
    public static void main(String[] args) {
        // Create an instance of AVLTree to manage courses in-memory
        AVLTree courseTree = new AVLTree();

        // Connect to the MongoDB database using CourseDatabase
        CourseDatabase db = new CourseDatabase();

        // Create a scanner for user input
        Scanner scanner = new Scanner(System.in);

        // Load all existing courses from MongoDB and insert into the AVL tree
        for (Course course : db.getAllCourses()) {
            courseTree.insertCourse(course);
        }

        // Show welcome message
        welcomeMessage();

        // Main application loop
        while (true) {
            // Show the menu options to the user
            displayMenu();
            System.out.print("\nChoice: ");

            int choice;
            try {
                // Read and parse the user's menu selection
                choice = Integer.parseInt(scanner.nextLine().trim());
            } catch (Exception e) {
                // Handle invalid number input
                System.out.println("⚠️ Please enter a valid number.");
                continue;
            }

            // Handle user choices using a switch statement
            switch (choice) {
                case 1:
                    // Option to add a new course
                    System.out.println("\n📘 Add New Course");
                    Course newCourse = getCourseInput(scanner); // Prompt for course info
                    courseTree.insertCourse(newCourse);         // Add to AVL tree
                    db.insertCourse(newCourse);                // Insert into MongoDB
                    break;
                case 2:
                    // Option to update an existing course
                    System.out.println("\n✏️ Update an Existing Course");
                    Course updatedCourse = getCourseInput(scanner); // Prompt for updated info
                    courseTree.updateCourse(updatedCourse);         // Update in AVL tree
                    db.updateCourse(updatedCourse);                 // Update in MongoDB
                    break;
                case 3:
                    // Option to delete a course
                    System.out.println("\n🗑️ Delete an Existing Course");
                    System.out.print("Enter course number to delete: ");
                    String courseToDelete = scanner.nextLine().trim(); // Get course number
                    courseTree.deleteCourse(courseToDelete);           // Remove from AVL tree
                    db.deleteCourse(courseToDelete);                   // Remove from MongoDB
                    break;
                case 4:
                    // Option to view all courses in order
                    System.out.println("\n📚 View All Courses");
                    courseTree.printInOrder(); // In-order traversal of AVL tree
                    break;
                case 5:
                    // Option to search for a course by its number
                    System.out.println("\n🔍 Search Course by Number");
                    System.out.print("Enter course number to search: ");
                    String courseNumber = scanner.nextLine().trim();

                    Course foundCourse = courseTree.searchCourse(courseNumber); // Search in AVL tree

                    // Display results of the search
                    if (foundCourse != null) {
                        System.out.println("✅ Course Found:");
                        System.out.println("Number: " + foundCourse.getCourseNumber());
                        System.out.println("Title: " + foundCourse.getCourseTitle());
                        System.out.println("Prerequisites: " + foundCourse.getPrerequisites());
                    } else {
                        System.out.println("❌ Course not found.");
                    }
                    break;

                case 9:
                    // Option to exit the program
                    System.out.println("\n👋 You've exited the program.");
                    scanner.close(); // Close the scanner
                    db.close();      // Close database connection
                    return;          // Exit the program
                default:
                    // Handle invalid menu choices
                    System.out.println("❌ Invalid entry. Please select a valid menu option.");
            }
        }
    }

    // Method to print a welcome message to the user
    public static void welcomeMessage() {
        System.out.println("\n📚 Course Navigator Pro 📚");
    }

    // Method to display the available menu options
    public static void displayMenu() {
        System.out.println("\nPlease select an option:");
        System.out.println("------------------------");
        System.out.println("1 | Add Course");
        System.out.println("2 | Update Course");
        System.out.println("3 | Delete Course");
        System.out.println("4 | View All Courses");
        System.out.println("5 | Search Course by Number");
        System.out.println("9 | Exit Program");
    }

    // Method to collect user input for creating or updating a course
    public static Course getCourseInput(Scanner scanner) {
        System.out.print("Enter course number (ex: CS499): ");
        String number = scanner.nextLine().trim(); // Read course number

        System.out.print("Enter course title: ");
        String title = scanner.nextLine().trim(); // Read course title

        System.out.print("Enter prerequisites (comma separated), or press Enter for none: ");
        String prereqInput = scanner.nextLine().trim(); // Read prerequisite input

        List<String> prerequisites = new ArrayList<>();

        // If prerequisites are provided, split by commas and trim spaces
        if (!prereqInput.isEmpty()) {
            for (String pre : prereqInput.split(",")) {
                prerequisites.add(pre.trim());
            }
        }

        // Return a new Course object based on user input
        return new Course(number, title, prerequisites);
    }
}
